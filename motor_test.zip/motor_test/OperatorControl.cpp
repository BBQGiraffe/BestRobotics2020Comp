// OperatorControl.cpp : implementation file

#include "MainCpp.h"

void OperatorControl ( unsigned long ulTime )
{

    while ( 1 )
    {
        PrintToScreen ( "Alex Is Epic\n" ) ; 
        // TODO: add your code here
        SetServo (2,127) ; 
       // JoystickToServo(1, 1, 2, 0);

    }

}


