// MainCpp.cpp : implementation file

#include "MainCpp.h"

void MainCpp ( )
{

    Initialize ( ) ;

    Autonomous ( 0 ) ;

    OperatorControl ( 0 ) ;

}


