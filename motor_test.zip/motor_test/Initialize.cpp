// Initialize.cpp : implementation file

#include "MainCpp.h"
#include "RobotConsts.h"

void Initialize ( )
{

    // Alex is Epic
    
    SetServo (1,127) ; 
}


