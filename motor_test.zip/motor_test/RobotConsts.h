// RobotConsts.h : header file
#include "MainCpp.h"

// TODO: add your code here
class RobotConsts{
public:
    const static int ClawBaseSpeed = 5;

};

