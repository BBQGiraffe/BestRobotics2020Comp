// MainCpp.h : header file

#ifndef _maincpp_h_
#define _maincpp_h_

#include "API.H"

void Initialize();
void Autonomous(unsigned long ulTime);
void OperatorControl(unsigned long ulTime);

// TODO: add your code here

#endif // _maincpp_h_
